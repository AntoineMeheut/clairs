import os

OS_PATH_DEFAULT_PATTERN_PATH = os.path.join(os.path.dirname(__file__), "..", "wordlists", "patterns.txt")
